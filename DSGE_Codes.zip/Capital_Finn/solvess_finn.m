function obj = solvess_finn(ssguess,parameters)

delta = parameters(1);
e = parameters(2);
k = parameters(3);
u = parameters(4);
y = parameters(5);
theta = parameters(6);
pe = parameters(7);

omega0 = ssguess(1);
omega1 = ssguess(2);
nu0 = ssguess(3);
nu1 = ssguess(4);
s = ssguess(5);
h = ssguess(6);

obj(1) = delta - (h^omega1)/omega1;
obj(2) = e/k - (h^nu1)/nu1;
obj(3) = (1-theta)*y/k - delta*omega1 - (pe*e/k)*nu1;
obj(4) = omega0*(u^omega1)/omega1 - (h^omega1)/omega1;
obj(5) = nu0*(u^nu1)/nu1 - (h^nu1)/nu1;
obj(6) = h - s*u;