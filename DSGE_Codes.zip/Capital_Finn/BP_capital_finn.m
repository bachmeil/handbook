% BP_capital_finn.m
%
% This code runs the model with capital accumultion and the production
% function found in Finn (2000).
%
% Key features: Exogenous supply of oil, capital accumulation, firm demand
% for energy, production function found in Finn, where utlization of
% capital is tied to energy usage.
%
% The codes all have the following structure:
%
% 1. Calibrate the shocks
% 2. Calibrate parameters and starting values (to the extent possible)
% 2b. Use a non-linear solver to finish the calibration (if necessary)
% 3. Run Dynare to solve the model
% 4. Plot impulse responses for the price of oil and for GDP.
%
% To run this file you will need to have Dynare installed.
% You will also need to have the file 'model_capital_finn.mod' in the same directory as this .m file.
%
% This software is released under the Boost License (see http://boost.org/LICENSE_1_0.txt for details).
% Feel free to use or modify this code for your own work. If you make use of this
% code we would appreciate a cite for our chapter (details below).
%
% Bachmeier, L. and Michael Plante (2019). In U. Soytas (Ed.), Routledge
% Handbook of Energy Economics. Oxfordshire, United Kingdom: Routledge.
%

clc,clear all

%% Part 1: Calibrate shocks

% Calibrate the shocks and save the values in one vector

rhozn       = 0.90;          % Technology persistence 
rhoe        = 0.90;          % Energy supply persistence

sigzn      = 0.001;         % Technology shock SD
sige       = 0.001;         % Energy supply shock SD

calibratedshock = [rhozn; rhoe; sigzn; sige];    

% Save the calibration to a .mat file that is loaded into the .mod file

save calibratedshock.mat calibratedshock

%% Part 2 Calibrate parameters and steady state

%---------------------------------------------------
% Calibrate some parameters and starting values
%---------------------------------------------------

% Calibrated Parameters
beta      = 0.99;               % Discount factor
eta       = 1;                  % Inverse Frisch elasticity of labor supply
theta =     0.64;               % Labor share of gross output
delta = 0.025;                   % Depreciation

% Normalized steady state values

n = 1;      % Labor
y = 1;      % Output (non-oil)
pe = 1;     % Relative price of energy

% In Finn (2000) energy is defined as electricity + fossil fuels. We use
% data on total spending on all energy.

energyshare_gdp = 0.075;    % GDP share of energy (total)
energyshare_cost  = energyshare_gdp/(1+energyshare_gdp);         % Cost-share of energy

e = energyshare_cost; % Given y and pe = 1;

u = 0.82;   %Utilization rate 

% Use steady state equations to solve for some starting values

% Firm FOC labor
w = theta*y/n;
% HH FOC capital
k = ((1-theta)*y - pe*e)/(1/beta - (1-delta));
% Firm FOC capital
rk = (1-theta)*y/(u*k);
% Production function
zn = (y/(((k*u)^(1-theta))*n^theta))^(1/theta);
% Law of motion for capital
inv = delta*k;
% Resource constraint
c = y - pe*e - inv;
% HH FOC c
lambda = 1/c;
% FOC labor
chi = w*lambda/(n^eta);
% GDP
gdp_ex = y - pe*e;
% GDP deflator
pg = (y-pe*e)/(y-e);

% Solve for omega0, omega1, nu0, and nu1 using fsolve. 
% You will need solvess_finn.m in the same directory.

optionsfsolve=optimset('fsolve');

% Guess vector is omega0, omega1, nu0 and nu1, s, h respectively. The
% guesses come from Table 1 in Finn (2000).

ssguess = [0.04;1.25;0.01;1.66;1;1];

parameters = [delta;e;k;u;y;theta;pe];

[ss, fval1, exitflag1] = fsolve(@solvess_finn,ssguess,optionsfsolve,parameters);

omega0 = ss(1);
omega1 = ss(2);
nu0 = ss(3);
nu1 = ss(4);

% Save the calibration to a .mat file that is loaded into the .mod file

calibratedparameters = [beta;eta;chi;theta;omega0;omega1;nu0;nu1;e;zn;delta;n;y;pe;w;c;gdp_ex;pg;lambda;rk;inv;k;u];

save calibratedparameters.mat calibratedparameters;

%% Part 3: Run dynare code

dynare model_capital_finn.mod;

%% Part 4: Plot figures

gdp_ex_ss = oo_.steady_state(12,1);
pe_ss = oo_.steady_state(15,1);
u_ss = oo_.steady_state(3,1);

scale_e = .10/((pe_epse(1,1))/pe_ss);
scale_zn = .10/((pe_epszn(1,1))/pe_ss);

figbox = [.5 .5 6.5 5];

%plotdim is rows by columns

plotdim = [3,2];

subpad.bot = .15; % Increase if xaxis lables are cut off
subpad.top = .2; % Increase if subplot title is cut off
subpad.left = .25; % Increase if ylabel is cut off
subpad.right = .10; % Decrease if white-space on RHS
subpad.legend = 0.01; % Increase if legend overlaps subplot titles
legfont = 10;

figure

col =1;
row =1;

left = (col-1+subpad.left)/plotdim(2);
bottom = 1-(row-subpad.bot)/plotdim(1)-subpad.legend*(plotdim(1)-row);
width = (1-(subpad.left+subpad.right))/plotdim(2);
height = (1-subpad.bot-subpad.top-subpad.legend)/plotdim(1);

subplot('Position',[left bottom width height]); 
grid on; hold on; box on;

plot(100*scale_e*(pe_epse(:,1))./pe_ss,'k-');
xlim([1 40]);
ylabel('Energy price','interpreter','latex','fontsize',10);
title('\rm Energy supply shock','Interpreter','latex','fontsize',10)
set(gca,'FontSize',8)

col =2;
row =1;

left = (col-1+subpad.left)/plotdim(2);
bottom = 1-(row-subpad.bot)/plotdim(1)-subpad.legend*(plotdim(1)-row);
width = (1-(subpad.left+subpad.right))/plotdim(2);
height = (1-subpad.bot-subpad.top-subpad.legend)/plotdim(1);

subplot('Position',[left bottom width height]); 
grid on; hold on; box on;

plot(100*scale_zn*(pe_epszn(:,1))./pe_ss,'k-');
xlim([1 40]);
title('\rm Productivity shock','Interpreter','latex','fontsize',10)
set(gca,'FontSize',8)

col =1;
row =2;

left = (col-1+subpad.left)/plotdim(2);
bottom = 1-(row-subpad.bot)/plotdim(1)-subpad.legend*(plotdim(1)-row);
width = (1-(subpad.left+subpad.right))/plotdim(2);
height = (1-subpad.bot-subpad.top-subpad.legend)/plotdim(1);

subplot('Position',[left bottom width height]); 
grid on; hold on; box on;

plot(100*scale_e*(gdp_ex_epse(:,1))./gdp_ex_ss,'k-');
xlim([1 40]);
ylabel('GDP (expenditure)','interpreter','latex','fontsize',10);
title('\rm Energy supply shock','Interpreter','latex','fontsize',10)
set(gca,'FontSize',8)

col =2;
row =2;

left = (col-1+subpad.left)/plotdim(2);
bottom = 1-(row-subpad.bot)/plotdim(1)-subpad.legend*(plotdim(1)-row);
width = (1-(subpad.left+subpad.right))/plotdim(2);
height = (1-subpad.bot-subpad.top-subpad.legend)/plotdim(1);

subplot('Position',[left bottom width height]); 
grid on; hold on; box on;

plot(100*scale_zn*(gdp_ex_epszn(:,1))./gdp_ex_ss,'k-');
xlim([1 40]);
title('\rm Productivity shock','Interpreter','latex','fontsize',10)
set(gca,'FontSize',8)

col =1;
row =3;

left = (col-1+subpad.left)/plotdim(2);
bottom = 1-(row-subpad.bot)/plotdim(1)-subpad.legend*(plotdim(1)-row);
width = (1-(subpad.left+subpad.right))/plotdim(2);
height = (1-subpad.bot-subpad.top-subpad.legend)/plotdim(1);

subplot('Position',[left bottom width height]); 
grid on; hold on; box on;

plot(scale_e*(u_epse(:,1))+u_ss,'k-');
xlim([1 40]);
ylabel('Utilization','interpreter','latex','fontsize',10);
title('\rm Energy supply shock','Interpreter','latex','fontsize',10)
set(gca,'FontSize',8)

col =2;
row =3;

left = (col-1+subpad.left)/plotdim(2);
bottom = 1-(row-subpad.bot)/plotdim(1)-subpad.legend*(plotdim(1)-row);
width = (1-(subpad.left+subpad.right))/plotdim(2);
height = (1-subpad.bot-subpad.top-subpad.legend)/plotdim(1);

subplot('Position',[left bottom width height]); 
grid on; hold on; box on;

plot(scale_zn*(u_epszn(:,1))+u_ss,'k-');
xlim([1 40]);
title('\rm Productivity shock','Interpreter','latex','fontsize',10)
set(gca,'FontSize',8)
