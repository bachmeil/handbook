% BP_capital_KL.m
%
% This code runs the model with firm and household demand.
%
% Key features: Exogenous supply of oil, capital accumulation, firm demand
% for energy, production function where capital is nested with
% energy. The production function is of the form found in Kim and Loungani
% (1992).
%
% The codes all have the following structure:
%
% 1. Calibrate the shocks
% 2. Calibrate parameters and starting values (to the extent possible)
% 2b. Use a non-linear solver to finish the calibration (if necessary)
% 3. Run Dynare to solve the model
% 4. Plot impulse responses for the price of oil and for GDP.
%
% To run this file you will need to have Dynare installed.% You will also need to have the file 'model_capital_KL.mod' in the same directory as this .m file.
%
% This software is released under the Boost License (see http://boost.org/LICENSE_1_0.txt for details).
% Feel free to use or modify this code for your own work. If you make use of this
% code we would appreciate a cite for our chapter (details below).
%
% Bachmeier, L. and Michael Plante (2019). In U. Soytas (Ed.), Routledge
% Handbook of Energy Economics. Oxfordshire, United Kingdom: Routledge.
%

clc,clear all
close all
%% Part 1: Calibrate shocks

% Calibrate the shocks and save the values in one vector

rhozn       = 0.90;          % Technology persistence 
rhoze       = 0.90;          % Energy efficiency persistence
rhoe        = 0.90;          % Energy supply persistence

sigzn      = 0.001;         % Technology shock SD
sigze      = 0.001;         % Energy efficiency shock SD
sige       = 0.001;         % Energy supply shock SD

calibratedshock = [rhozn; rhoze; rhoe; sigzn; sigze; sige];    

% Save the calibration to a .mat file that is loaded into the .mod file

save calibratedshock.mat calibratedshock

%% Part 2 Calibrate parameters and steady state

%---------------------------------------------------
% Calibrate some parameters and starting values
%---------------------------------------------------

% Calibrate to an annual frequency

% Calibrated Parameters
beta      = 0.96;               % Discount factor
eta       = 1;                  % Inverse Frisch elasticity of labor supply
sigmae     = 0.59;              % Elasticity of substitution. In KL the paramter is nu and sigmae = 1 / (1 + nu).
theta =     0.64;               % Labor share of gross output
delta = 0.10;                   % Depreciation

% The following is for a quarterly calibration

% beta      = 0.99;               % Discount factor
% eta       = 1;                  % Inverse Frisch elasticity of labor supply
% sigmae     = 0.25;              % Elasticity of substitution. In KL the paramter is nu and sigmae = 1 / (1 + nu).
% theta =     0.64;               % Labor share of gross output
% delta = 0.025;                   % Depreciation

% Normalized steady state values

n = 1;      % Labor
y = 1;      % Output (non-oil)
pe = 1;     % Relative price of energy

% Set the cost-share of oil

energyshare_gdp = 0.054;    % GDP share of energy (total)
energyshare_cost  = energyshare_gdp/(1+energyshare_gdp);         % Cost-share of energy

e = energyshare_cost; % Given y and pe = 1;

% Use steady state equations to solve for some starting values

% Firm FOC labor
w = theta*y/n;
% HH FOC capital
rk = 1/beta - (1-delta);

% Solve for alphae, k, ze, and zn using fsolve. You will need solvess.m in
% the same directory.
%
% The function solvess can be edited to solve for the case where ze = 1 or
% where ze is normalized to ensure that alphae is equal to a cost-share.

optionsfsolve=optimset('fsolve');

% Guess vector is alphae, k, ze and zn, respectively.

ssguess = [.01;1.7;2;1];

parameters = [sigmae;e;rk;theta;y;n;pe];

[ss, fval1, exitflag1] = fsolve(@solvess_kl,ssguess,optionsfsolve,parameters);

alphae = ss(1);
k = ss(2);
ze = ss(3);
zn = ss(4);

%Capital law of motion
inv = delta*k;
% Aggregate resouce constraint
c = y-pe*e - inv;
% HH FOC c
lambda = 1/c;
% FOC labor
chi = w*lambda/(n^eta);
% GDP
gdp_ex = y - pe*e;
% GDP deflator
pg = (y-pe*e)/(y-e);

% Save the calibration to a .mat file that is loaded into the .mod file

calibratedparameters = [beta;eta;alphae;chi;sigmae;delta;theta;e;zn;ze;n;y;pe;w;c;gdp_ex;lambda;rk;inv;k];

save calibratedparameters.mat calibratedparameters;

%% Part 3: Run dynare code

dynare model_capital_kl.mod;

%% Part 4: Plot figures

gdp_ex_ss = oo_.steady_state(10,1);
pe_ss = oo_.steady_state(13,1);

scale_e = .10/((pe_epse(1,1))/pe_ss);
scale_zn = .10/((pe_epszn(1,1))/pe_ss);
scale_ze = .10/((pe_epsze(1,1))/pe_ss);

figbox = [.5 .5 6.5 3.75];

%plotdim is rows by columns

plotdim = [2,3];

subpad.bot = .15; % Increase if xaxis lables are cut off
subpad.top = .2; % Increase if subplot title is cut off
subpad.left = .25; % Increase if ylabel is cut off
subpad.right = .10; % Decrease if white-space on RHS
subpad.legend = 0.01; % Increase if legend overlaps subplot titles
legfont = 10;

figure

col =1;
row =1;

%ivar = row; ishock = col;
left = (col-1+subpad.left)/plotdim(2);
bottom = 1-(row-subpad.bot)/plotdim(1)-subpad.legend*(plotdim(1)-row);
width = (1-(subpad.left+subpad.right))/plotdim(2);
height = (1-subpad.bot-subpad.top-subpad.legend)/plotdim(1);

subplot('Position',[left bottom width height]); 
grid on; hold on; box on;

plot(100*scale_e*(pe_epse(:,1))./pe_ss,'k-');
xlim([1 40]);
ylabel('Energy price','interpreter','latex','fontsize',10);
title('\rm Energy supply shock','Interpreter','latex','fontsize',10)
set(gca,'FontSize',8)

col =2;
row =1;

left = (col-1+subpad.left)/plotdim(2);
bottom = 1-(row-subpad.bot)/plotdim(1)-subpad.legend*(plotdim(1)-row);
width = (1-(subpad.left+subpad.right))/plotdim(2);
height = (1-subpad.bot-subpad.top-subpad.legend)/plotdim(1);

subplot('Position',[left bottom width height]); 
grid on; hold on; box on;

plot(100*scale_zn*(pe_epszn(:,1))./pe_ss,'k-');
xlim([1 40]);
title('\rm Productivity shock','Interpreter','latex','fontsize',10)
set(gca,'FontSize',8)

col =3;
row =1;

left = (col-1+subpad.left)/plotdim(2);
bottom = 1-(row-subpad.bot)/plotdim(1)-subpad.legend*(plotdim(1)-row);
width = (1-(subpad.left+subpad.right))/plotdim(2);
height = (1-subpad.bot-subpad.top-subpad.legend)/plotdim(1);

subplot('Position',[left bottom width height]); 
grid on; hold on; box on;

plot(100*scale_ze*(pe_epsze(:,1))./pe_ss,'k-');
xlim([1 40]);
title('\rm Energy-efficiency shock','Interpreter','latex','fontsize',10)
set(gca,'FontSize',8)

col =1;
row =2;

left = (col-1+subpad.left)/plotdim(2);
bottom = 1-(row-subpad.bot)/plotdim(1)-subpad.legend*(plotdim(1)-row);
width = (1-(subpad.left+subpad.right))/plotdim(2);
height = (1-subpad.bot-subpad.top-subpad.legend)/plotdim(1);

subplot('Position',[left bottom width height]); 
grid on; hold on; box on;

plot(100*scale_e*(gdp_ex_epse(:,1))./gdp_ex_ss,'k-');
xlim([1 40]);
ylabel('GDP (expenditure)','interpreter','latex','fontsize',10);
title('\rm Energy supply shock','Interpreter','latex','fontsize',10)
set(gca,'FontSize',8)

col =2;
row =2;

left = (col-1+subpad.left)/plotdim(2);
bottom = 1-(row-subpad.bot)/plotdim(1)-subpad.legend*(plotdim(1)-row);
width = (1-(subpad.left+subpad.right))/plotdim(2);
height = (1-subpad.bot-subpad.top-subpad.legend)/plotdim(1);

subplot('Position',[left bottom width height]); 
grid on; hold on; box on;

plot(100*scale_zn*(gdp_ex_epszn(:,1))./gdp_ex_ss,'k-');
xlim([1 40]);
title('\rm Productivity shock','Interpreter','latex','fontsize',10)
set(gca,'FontSize',8)

col =3;
row =2;

left = (col-1+subpad.left)/plotdim(2);
bottom = 1-(row-subpad.bot)/plotdim(1)-subpad.legend*(plotdim(1)-row);
width = (1-(subpad.left+subpad.right))/plotdim(2);
height = (1-subpad.bot-subpad.top-subpad.legend)/plotdim(1);

subplot('Position',[left bottom width height]); 
grid on; hold on; box on;

plot(100*scale_ze*(gdp_ex_epsze(:,1))./gdp_ex_ss,'k-');
xlim([1 40]);
title('\rm Energy-efficiency shock','Interpreter','latex','fontsize',10)
set(gca,'FontSize',8)
