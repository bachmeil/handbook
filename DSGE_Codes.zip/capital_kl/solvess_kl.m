function obj = solvess_kl(ssguess,parameters)

sigmae = parameters(1);
e = parameters(2);
rk = parameters(3);
theta = parameters(4);
y = parameters(5);
n = parameters(6);
pe = parameters(7);

alphae = ssguess(1);
k = ssguess(2);
ze = ssguess(3);
zn = ssguess(4);

obj(1) = alphae - 1/(1 + (ze^((sigmae-1)/sigmae))*((k/e)^(1/sigmae))*(rk/pe));
obj(2) = (1-theta)*(1-alphae)*y*(k^(-1/sigmae))/((1-alphae)*k^((sigmae-1)/sigmae) + alphae*(ze*e)^((sigmae-1)/sigmae)) - rk;
obj(3) = y - ((zn*n)^theta)*((1-alphae)*k^((sigmae-1)/sigmae) + alphae*(ze*e)^((sigmae-1)/sigmae))^((1-theta)*(sigmae/(sigmae-1)));
%obj(4) = ze - 1;
obj(4) = ze - k/e;