% BP_hh.m
%
% This code runs the model with firm and household demand.
%
% Key features: Exogenous supply of oil, CES production function, CES utility function, no
% capital, household and firm demand for oil.
%
% The codes all have the following structure:
%
% 1. Calibrate the shocks
% 2. Calibrate parameters and starting values (to the extent possible)
% 2b. Use a non-linear solver to finish the calibration (if necessary)
% 3. Run Dynare to solve the model
% 4. Plot impulse responses for the price of oil and for GDP.
%
% To run this file you will need to have Dynare installed.
% You will also need to have the file 'model_hh.mod' in the same directory as this .m file.
%
% This software is released under the Boost License (see http://boost.org/LICENSE_1_0.txt for details).
% Feel free to use or modify this code for your own work. If you make use of this
% code we would appreciate a cite for our chapter (details below).
%
% Bachmeier, L. and Michael Plante (2019). In U. Soytas (Ed.), Routledge
% Handbook of Energy Economics. Oxfordshire, United Kingdom: Routledge.
%

clc,clear all

%% Part 1: Calibrate shocks

% Calibrate the shocks and save the values in one vector

rhozn           = 0.90;          % Technology persistence 
rhozop          = 0.90;          % Oil efficiency persistence for firms
rhozoc          = 0.90;          % Oil efficiency persistence for hh
rhoo            = 0.90;          % Oil supply persistence

sigzn           = 0.001;         % Technology shock SD
sigzop          = 0.001;         % Oil efficiency shock SD for firms
sigzoc          = 0.001;         % Oil efficiency shock SD for hh
sigo            = 0.001;         % Oil supply shock SD

calibratedshock = [rhozn; rhozop; rhozoc; rhoo; sigzn; sigzop; sigzoc; sigo];    

% Save the calibration to a .mat file that is loaded into the .mod file

save calibratedshock.mat calibratedshock

%% Part 2 Calibrate parameters and steady state

%---------------------------------------------------
% Calibrate some parameters and starting values
%---------------------------------------------------

% Calibrated Parameters
beta        = 0.99;                 % Discount factor
eta         = 1;                    % Inverse Frisch elasticity of labor supply
sigmap      = 1/4;                  % Elasticity of substitution (Firms)
sigmac      = sigmap;               % Elasticity of substitution (Household)

% Normalized steady state values

n = 1;      % Labor
y = 1;      % Output (non-oil)
po = 1;     % Relative price of oil
zn = 1;     % Labor-augmenting technology

% Set zoc to 1 if desired. A line later on allows one to set zoc to a different value.

% zoc = 1;    % Oil efficiency shock (Household)

% Calibrate firm oil consumption to match its GDP share.

oilshare_firm_gdp = 0.02;    % GDP share of oil (firm)
oilshare_firm_cost  = oilshare_firm_gdp/(1+oilshare_firm_gdp);         % Cost-share of oil

op = oilshare_firm_cost;

% Calibrate HH oil consumption to match its GDP share

oilshare_hh_gdp = 0.02; % GDP share of oil (Household)

oc = oilshare_hh_gdp*(y - po*op);

% Use steady state equations to solve for some starting values

% Production function
zop = 1/op;
% Firm FOC oil
alphaop = zop^(-(sigmap-1)/sigmap)*po*(op/y)^(1/sigmap);
% Firm FOC labor
w = (1-alphaop)*((y/n)^(1/sigmap))*(zn^((sigmap-1)/sigmap));
% Aggregate resouce constraint
cn = y-po*op - po*oc;

% Set zoc = cn/oc. This ensures that alphaoc is equal to the
% consumption-expenditure share of oil.

zoc = cn/oc;

% Combine HH foc for cn and oc
alphaoc = 1/(1 + zoc^((sigmac-1)/sigmac)*(cn^(1/sigmac))/(po*(oc^(1/sigmac))));
% CES aggregator for c
c = ((1-alphaoc)*(cn^((sigmac-1)/sigmac)) + alphaoc*(oc*zoc)^((sigmac-1)/sigmac))^(sigmac/(sigmac-1));
% HH FOC cn
lambda = (1-alphaoc)*(c^((1/sigmac)-1))*(cn^(-1/sigmac));
% FOC labor
chi = w*lambda/(n^eta);

% GDP
gdp = y - po*op;
%GDP deflator
pg = (y-po*op)/(y-op);
% Oil supply
osupply = oc + op;

% Save the calibration to a .mat file that is loaded into the .mod file

calibratedparameters = [beta;eta;alphaop;alphaoc;chi;sigmap;sigmac;op;oc;osupply;zn;zop;zoc;n;y;po;w;cn;c;gdp;lambda;pg];

save calibratedparameters.mat calibratedparameters;

%% Part 3: Run dynare code

dynare model_hh.mod;

%% Part 4: Plot figures

gdp_ex_ss = oo_.steady_state(9,1);
gdp_va_ss = oo_.steady_state(10,1);
po_ss = oo_.steady_state(12,1);

scale_o = .10/((po_epso(1,1))/po_ss);
scale_zn = .10/((po_epszn(1,1))/po_ss);
scale_zop = .10/((po_epszoc(1,1))/po_ss);
scale_zoc = .10/((po_epszop(1,1))/po_ss);


figbox = [.5 .5 6.5 6];

%plotdim is rows by columns

plotdim = [2,4];

subpad.bot = .15; % Increase if xaxis lables are cut off
subpad.top = .2; % Increase if subplot title is cut off
subpad.left = .25; % Increase if ylabel is cut off
subpad.right = .10; % Decrease if white-space on RHS
subpad.legend = 0.01; % Increase if legend overlaps subplot titles
legfont = 10;

figure

col =1;
row =1;

%ivar = row; ishock = col;
left = (col-1+subpad.left)/plotdim(2);
bottom = 1-(row-subpad.bot)/plotdim(1)-subpad.legend*(plotdim(1)-row);
width = (1-(subpad.left+subpad.right))/plotdim(2);
height = (1-subpad.bot-subpad.top-subpad.legend)/plotdim(1);

subplot('Position',[left bottom width height]); 
grid on; hold on; box on;

plot(100*scale_o*(po_epso(:,1))./po_ss,'k-');
xlim([1 40]);
%xticks(years(1):2:years(end))
ylabel('Oil price','interpreter','latex','fontsize',10);
title('\rm Oil supply shock','Interpreter','latex','fontsize',10)
set(gca,'FontSize',8)

col =2;
row =1;

%ivar = row; ishock = col;
left = (col-1+subpad.left)/plotdim(2);
bottom = 1-(row-subpad.bot)/plotdim(1)-subpad.legend*(plotdim(1)-row);
width = (1-(subpad.left+subpad.right))/plotdim(2);
height = (1-subpad.bot-subpad.top-subpad.legend)/plotdim(1);

subplot('Position',[left bottom width height]); 
grid on; hold on; box on;

plot(100*scale_zn*(po_epszn(:,1))./po_ss,'k-');
xlim([1 40]);
%xticks(years(1):2:years(end))
%ylabel('Oil price','interpreter','latex','fontsize',10);
title('\rm Productivity shock','Interpreter','latex','fontsize',10)
set(gca,'FontSize',8)

col =3;
row =1;

%ivar = row; ishock = col;
left = (col-1+subpad.left)/plotdim(2);
bottom = 1-(row-subpad.bot)/plotdim(1)-subpad.legend*(plotdim(1)-row);
width = (1-(subpad.left+subpad.right))/plotdim(2);
height = (1-subpad.bot-subpad.top-subpad.legend)/plotdim(1);

subplot('Position',[left bottom width height]); 
grid on; hold on; box on;

plot(100*scale_zop*(po_epszop(:,1))./po_ss,'k-');
xlim([1 40]);
title('\rm Oil-efficiency (firms)','Interpreter','latex','fontsize',10)
set(gca,'FontSize',8)

col =4;
row =1;

%ivar = row; ishock = col;
left = (col-1+subpad.left)/plotdim(2);
bottom = 1-(row-subpad.bot)/plotdim(1)-subpad.legend*(plotdim(1)-row);
width = (1-(subpad.left+subpad.right))/plotdim(2);
height = (1-subpad.bot-subpad.top-subpad.legend)/plotdim(1);

subplot('Position',[left bottom width height]); 
grid on; hold on; box on;

plot(100*scale_zoc*(po_epszoc(:,1))./po_ss,'k-');
xlim([1 40]);
title('\rm Oil-efficiency (hh)','Interpreter','latex','fontsize',10)
set(gca,'FontSize',8)

col =1;
row =2;

%ivar = row; ishock = col;
left = (col-1+subpad.left)/plotdim(2);
bottom = 1-(row-subpad.bot)/plotdim(1)-subpad.legend*(plotdim(1)-row);
width = (1-(subpad.left+subpad.right))/plotdim(2);
height = (1-subpad.bot-subpad.top-subpad.legend)/plotdim(1);

subplot('Position',[left bottom width height]); 
grid on; hold on; box on;

plot(1:size(gdp_ex_epso),100*scale_o*(gdp_ex_epso(:,1))./gdp_ex_ss,'k-');
xlim([1 40]);
%xticks(years(1):2:years(end))
ylabel('GDP (expenditure)','interpreter','latex','fontsize',10);
title('\rm Oil supply shock','Interpreter','latex','fontsize',10)
set(gca,'FontSize',8)

col =2;
row =2;

%ivar = row; ishock = col;
left = (col-1+subpad.left)/plotdim(2);
bottom = 1-(row-subpad.bot)/plotdim(1)-subpad.legend*(plotdim(1)-row);
width = (1-(subpad.left+subpad.right))/plotdim(2);
height = (1-subpad.bot-subpad.top-subpad.legend)/plotdim(1);

subplot('Position',[left bottom width height]); 
grid on; hold on; box on;

plot(1:size(gdp_ex_epszn),100*scale_zn*(gdp_ex_epszn(:,1))./gdp_ex_ss,'k-');
xlim([1 40]);

title('\rm Productivity shock','Interpreter','latex','fontsize',10)
set(gca,'FontSize',8)

col =3;
row =2;

%ivar = row; ishock = col;
left = (col-1+subpad.left)/plotdim(2);
bottom = 1-(row-subpad.bot)/plotdim(1)-subpad.legend*(plotdim(1)-row);
width = (1-(subpad.left+subpad.right))/plotdim(2);
height = (1-subpad.bot-subpad.top-subpad.legend)/plotdim(1);

subplot('Position',[left bottom width height]); 
grid on; hold on; box on;

plot(1:size(gdp_ex_epszop),100*scale_zop*(gdp_ex_epszop(:,1))./gdp_ex_ss,'k-');
xlim([1 40]);

title('\rm Oil-efficiency (firms)','Interpreter','latex','fontsize',10)
set(gca,'FontSize',8)

col =4;
row =2;

%ivar = row; ishock = col;
left = (col-1+subpad.left)/plotdim(2);
bottom = 1-(row-subpad.bot)/plotdim(1)-subpad.legend*(plotdim(1)-row);
width = (1-(subpad.left+subpad.right))/plotdim(2);
height = (1-subpad.bot-subpad.top-subpad.legend)/plotdim(1);

subplot('Position',[left bottom width height]); 
grid on; hold on; box on;

plot(1:size(gdp_ex_epszoc),100*scale_zoc*(gdp_ex_epszoc(:,1))./gdp_ex_ss,'k-');
xlim([1 40]);

title('\rm Oil-efficiency (hh)','Interpreter','latex','fontsize',10)
set(gca,'FontSize',8)