% BP_basic.m
%
% This code runs the DSGE model introduced in Bachmeier and Plante (2019).
%
% In the online appendix, this is refereed to as the basic model.
% Key features: Exogenous supply of oil, CES production function, no
% capital, only firm demand for oil.
%
% The codes all have the following structure:
%
% 1. Calibrate the shocks
% 2. Calibrate parameters and starting values (to the extent possible)
% 2b. Use a non-linear solver to finish the calibration (if necessary)
% 3. Run Dynare to solve the model
% 4. Plot impulse responses for the price of oil and for GDP.
%
% To run this file you will need to have Dynare installed.
% You will also need to have the file 'model_basic.mod' in the same directory as this .m file.
%
% This software is released under the Boost License (see http://boost.org/LICENSE_1_0.txt for details).
% Feel free to use or modify this code for your own work. If you make use of this
% code we would appreciate a cite for our chapter (details below).
%
% Bachmeier, L. and Michael Plante (2019). In U. Soytas (Ed.), Routledge
% Handbook of Energy Economics. Oxfordshire, United Kingdom: Routledge.
%

clc,clear all

%% Part 1: Calibrate shocks

% Calibrate the shocks and save the values in one vector

rhozn       = 0.90;          % Technology persistence 
rhozo       = 0.90;          % Oil efficiency persistence (not discussed in chapter) 
rhoo        = 0.90;          % Oil supply persistence

sigzn      = 0.001;         % Technology shock SD
sigzo      = 0.001;         % Oil efficiency shock SD
sigo       = 0.001;         % Oil supply shock SD

calibratedshock = [rhozn; rhozo; rhoo; sigzn; sigzo; sigo];    

% Save the calibration to a .mat file that is loaded into the .mod file

save calibratedshock.mat calibratedshock

%% Part 2 Calibrate parameters and steady state

%---------------------------------------------------
% Calibrate some parameters and starting values
%---------------------------------------------------

% Calibrated Parameters
beta      = 0.99;               % Discount factor
eta       = 1;                  % Inverse Frisch elasticity of labor supply
sigma     = 1/4;                % Elasticity of substitution

% Normalized steady state values

n = 1;      % Labor
y = 1;      % Output (non-oil)
po = 1;     % Relative price of oil
zn = 1;     % Labor-augmenting technology

% Set the cost-share of oil

oilshare_gdp = 0.02;            % GDP share of oil (firm spending)
oilshare_cost  = oilshare_gdp/(1+oilshare_gdp);         % Cost-share of oil

% The value of o is set based on po*o = (oilshare_gdp/(1+oilshare_gdp))*y

o = oilshare_cost;

% Use steady state equations to solve for some starting values

% Production function
zo = 1/o;
% Firm FOC oil
alphao = po*((o/y)^(1/sigma))*(1/(zo^((sigma-1)/sigma)));
% Firm FOC labor
w = (1-alphao)*((y/n)^(1/sigma))*(zn^((sigma-1)/sigma));
% Aggregate resouce constraint
c = y-po*o;
% HH FOC c
lambda = 1/c;
% FOC labor
chi = w*lambda/(n^eta);
% GDP
gdp = y - po*o;
% GDP deflator (equals 1)
pg = (y-po*o)/(y-o);
% Save the calibration to a .mat file that is loaded into the .mod file

calibratedparameters = [beta;eta;alphao;chi;sigma;o;zn;zo;n;y;po;w;c;gdp;lambda;pg];

save calibratedparameters.mat calibratedparameters;

%% Part 3: Run dynare code

dynare model_basic.mod;

%% Part 4: Plot figures

gdp_ss = oo_.steady_state(7,1);
po_ss = oo_.steady_state(9,1);

scale_o = .10/((po_epso(1,1))/po_ss);
scale_zn = .10/((po_epszn(1,1))/po_ss);
scale_zo = .10/((po_epszo(1,1))/po_ss);

figbox = [.5 .5 6.5 3.75];

%plotdim is rows by columns

plotdim = [2,3];

subpad.bot = .15; % Increase if xaxis lables are cut off
subpad.top = .2; % Increase if subplot title is cut off
subpad.left = .25; % Increase if ylabel is cut off
subpad.right = .10; % Decrease if white-space on RHS
subpad.legend = 0.01; % Increase if legend overlaps subplot titles
legfont = 10;

figure

col =1;
row =1;

left = (col-1+subpad.left)/plotdim(2);
bottom = 1-(row-subpad.bot)/plotdim(1)-subpad.legend*(plotdim(1)-row);
width = (1-(subpad.left+subpad.right))/plotdim(2);
height = (1-subpad.bot-subpad.top-subpad.legend)/plotdim(1);

subplot('Position',[left bottom width height]); 
grid on; hold on; box on;

plot(100*scale_o*(po_epso(:,1))./po_ss,'k-');
xlim([1 40]);
ylabel('Oil price','interpreter','latex','fontsize',10);
title('\rm Oil supply shock','Interpreter','latex','fontsize',10)
set(gca,'FontSize',8)

col =2;
row =1;

left = (col-1+subpad.left)/plotdim(2);
bottom = 1-(row-subpad.bot)/plotdim(1)-subpad.legend*(plotdim(1)-row);
width = (1-(subpad.left+subpad.right))/plotdim(2);
height = (1-subpad.bot-subpad.top-subpad.legend)/plotdim(1);

subplot('Position',[left bottom width height]); 
grid on; hold on; box on;

plot(100*scale_zn*(po_epszn(:,1))./po_ss,'k-');
xlim([1 40]);
title('\rm Productivity shock','Interpreter','latex','fontsize',10)
set(gca,'FontSize',8)

col =3;
row =1;

left = (col-1+subpad.left)/plotdim(2);
bottom = 1-(row-subpad.bot)/plotdim(1)-subpad.legend*(plotdim(1)-row);
width = (1-(subpad.left+subpad.right))/plotdim(2);
height = (1-subpad.bot-subpad.top-subpad.legend)/plotdim(1);

subplot('Position',[left bottom width height]); 
grid on; hold on; box on;

plot(100*scale_zo*(po_epszo(:,1))./po_ss,'k-');
xlim([1 40]);
title('\rm Oil-efficiency shock','Interpreter','latex','fontsize',10)
set(gca,'FontSize',8)

col =1;
row =2;

left = (col-1+subpad.left)/plotdim(2);
bottom = 1-(row-subpad.bot)/plotdim(1)-subpad.legend*(plotdim(1)-row);
width = (1-(subpad.left+subpad.right))/plotdim(2);
height = (1-subpad.bot-subpad.top-subpad.legend)/plotdim(1);

subplot('Position',[left bottom width height]); 
grid on; hold on; box on;

plot(100*scale_o*(gdp_ex_epso(:,1))./gdp_ss,'k-');
xlim([1 40]);
ylabel('GDP (expenditure)','interpreter','latex','fontsize',10);
title('\rm Oil supply shock','Interpreter','latex','fontsize',10)
set(gca,'FontSize',8)

col =2;
row =2;

left = (col-1+subpad.left)/plotdim(2);
bottom = 1-(row-subpad.bot)/plotdim(1)-subpad.legend*(plotdim(1)-row);
width = (1-(subpad.left+subpad.right))/plotdim(2);
height = (1-subpad.bot-subpad.top-subpad.legend)/plotdim(1);

subplot('Position',[left bottom width height]); 
grid on; hold on; box on;

plot(100*scale_zn*(gdp_ex_epszn(:,1))./gdp_ss,'k-');
xlim([1 40]);
title('\rm Productivity shock','Interpreter','latex','fontsize',10)
set(gca,'FontSize',8)

col =3;
row =2;

left = (col-1+subpad.left)/plotdim(2);
bottom = 1-(row-subpad.bot)/plotdim(1)-subpad.legend*(plotdim(1)-row);
width = (1-(subpad.left+subpad.right))/plotdim(2);
height = (1-subpad.bot-subpad.top-subpad.legend)/plotdim(1);

subplot('Position',[left bottom width height]); 
grid on; hold on; box on;

plot(100*scale_zo*(gdp_ex_epszo(:,1))./gdp_ss,'k-');
xlim([1 40]);
title('\rm Oil-efficiency shock','Interpreter','latex','fontsize',10)
set(gca,'FontSize',8)